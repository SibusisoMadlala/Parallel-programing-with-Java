/* Assignment1 Mean FIlter parallel code
* 9 August 2022
* SIbusiso Madlala
*/

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveAction;
import java.io.File;
import java.io.IOException;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.awt.Graphics;

public class MeanFilterParallel extends RecursiveAction{
     
    
    static int SEQUENTIAL_CUFFOFF;
     int hi;
     int lo;
     int[] outPixels;
    static int w;
    static int width;
    static int height;
    
    // instintiates the class
    public MeanFilterParallel(int[] out,int l,int h, int windo,int wid, int higt){
        
        hi=h;
        lo=l;
        outPixels=out;
        w=windo;
        width=wid;
        height=higt;
    }
    
    // main method
    public static void main(String[] args){
    
        // calculates available Processors
       // int pros = Runtime.getRuntime().availableProcessors();
        
       // System.out.println(pros);
        try{
            
            // reading input files
            File input = new File(args[0]);
            File output = new File(args[1]);
            int window = Integer.parseInt(args[2]);
            
            if(window%2==0 || window<3){
                System.out.println("Enter odd number greater or equal 3");
                System.exit(0);
            }
            
            if (input==null || output==null){
                System.out.println("please enter file paths and window");
                System.exit(0);
            }	
            BufferedImage inputImage = ImageIO.read(input);
            
            // creating array of pixel
            int[] inPixels = inputImage.getRGB(0,0,inputImage.getWidth(),inputImage.getHeight(),
                                        null,0,inputImage.getWidth());
                                        
            
            // filtering array annd writing to image         
            BufferedImage outImage = meanfilter( window, inPixels,inputImage.getWidth(),inputImage.getHeight());
                            
            ImageIO.write(outImage, "png" , output);
            
        }
        catch(IOException e){System.out.println(e);}
        
        
    }
    
    // mean fiilter method creates fork join pool to filter pixel array
    public static BufferedImage meanfilter(int w, int[] outP, int wid, int hei){
        
        MeanFilterParallel mfp = new MeanFilterParallel(outP,0,outP.length,w,wid,hei);
    
        ForkJoinPool fjp =  new ForkJoinPool();
        
        long st = System.currentTimeMillis();// starts the time        
        fjp.invoke(mfp);
        long end = System.currentTimeMillis(); // ends the time
        
        System.out.println("The code took "+(end-st)+" milliseconds to execute");
        
        outP = mfp.outPixels;
         
        BufferedImage outImage = new BufferedImage(wid,hei,BufferedImage.TYPE_INT_ARGB);
        outImage.setRGB(0,0,wid,hei,outP,0,wid);
        
        return outImage;
    }
    
    // when invoke is called compute executes
    public void compute(){
        
        // divide and conque       
        if ((hi-lo)<=(outPixels.length)/12){
                    
            filter();
            return;
        }
        
        MeanFilterParallel left = new MeanFilterParallel(outPixels,lo,(hi+lo)/2,w,width,height);
        MeanFilterParallel right = new MeanFilterParallel(outPixels,(hi+lo)/2,hi,w,width,height);
        
        invokeAll(left,right);    
                            
        
    }
    
    // filters the array 
    public void filter(){
        
        
        int[] inPixels = outPixels;        
        int box = w*w;
        
        // this part stops and shift the window when border pixels are met
        int sidePixels = (w-1)/2;
        int stopWindow=0;
        
        if(lo==0){
             stopWindow = width;}
            
        if(lo!=0){
            int n = lo/width-1;
            
            while(lo>width*n){
                n++;
            }
            
            stopWindow=width*n;
        }
            
            
        int lastWindow=width*height;
        if(hi==width*height){lastWindow = hi-width*(w-1)-(w-1);}
        
        // window shift technique
        for (int y=lo;y<hi;y++){
                      
            float alpha=0,red=0, green=0, blue=0;
            int g=0;
            int u=0;
            int targetPixel=0;
            
            if (y==lastWindow){break;}
            
            if ((stopWindow-y)<w && lo==0){
                stopWindow+=width;
                y+=(w-1);
            }
            
            if((stopWindow-y)<w && lo!=0){
                stopWindow+=width;
                y+=(w-1);
            }
            
            // calculates averages 
            for (int i =0 ; i<box;i++){
                
                alpha+=(float)((inPixels[g+y] & 0xff000000) >> 24);
                red+=(float)((inPixels[g+y] & 0x00ff0000) >> 16);
                green+=(float)((inPixels[g+y] & 0x0000ff00) >> 8);
                blue+=(float)((inPixels[g+y] & 0x000000ff) >> 0);
                
                u++;
                if (u==w){
                    if(i==box-1){
                        alpha=alpha/box;
                        red=red/box;
                        green=green/box;
                        blue=blue/box;
                        
                        targetPixel = (0xff000000) | (((int) alpha) << 24)
                                                   | (((int) red) << 16)
                                                   | (((int) green) << 8)
                                                   | (((int) blue) << 0);
                        
                                         
                        outPixels[(g+y)-(width*sidePixels)-sidePixels]=targetPixel;
                        break;
                    }
                    g=g+width-w;
                    u=0;
                    
                }    
                g++;
            }     
        }
        
    }
}
