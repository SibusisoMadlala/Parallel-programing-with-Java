/* Assignment1 Median FIlter serial code
* 8 August 2022
* SIbusiso Madlala
*/

import java.util.Arrays;
import java.io.File;
import java.io.IOException;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.awt.Graphics;


public class MedianFilterSerial{
    
    //main method
    public static void main(String[] args){
    
        try{
            
            //this section reads input
            File input = new File(args[0]);
            File output = new File(args[1]);
            int window = Integer.parseInt(args[2]);
            
            if(window%2==0 || window<3){
                System.out.println("enter odd number greater than or equal 3");
                System.exit(0);
            }
            if (input==null || output==null){
                System.out.println("please enter file paths and window");
                System.exit(0);
            }
            
            BufferedImage inputImage = ImageIO.read(input);
            BufferedImage outImage = filter(inputImage, window);
                    
            ImageIO.write(outImage, "png" , output);
            
        }
        catch(IOException e){System.out.println(e);}
    }
    
    //this method median filters the image and returns a bufferedImage
    public static BufferedImage filter(BufferedImage image, int w){
        
        long start = System.currentTimeMillis();        
        int width = image.getWidth();
        int height = image.getHeight();
        
        // creating pixels array, one for updating and one outputing
        int[] inputPixels = image.getRGB(0,0,width,height,null,0,width);
        int[] outputPixels = image.getRGB(0,0,width,height,null,0,width);
                
        //this section deals with border pixels
        int box = w*w;
        int targetColour = (box+1)/2;
        int sidePixels = (w-1)/2;
        int stopWindow = width;
        int lastWindow = (width)*(height-(w-1))-(w-1);
        
        float[] alpha = null, red = null, green = null, blue = null;
        
        //these two nested for loops apply the window shift technique together
        // wth above instintiations
        
        for (int y=0;y<inputPixels.length;y++){
            
             alpha= new float[box];
             red = new float[box];
             green = new float[box];
             blue = new float[box];
            
            int g=0;
            int u=0;
            int targetPixel=0;
            int pixel = 0 ;
            
            if (y==lastWindow){break;}
            
            if ((stopWindow-y)<w){
                stopWindow+=width;
                y+=(w-1);
            }
            
            
            for (int i =0 ; i<box;i++){
                
                pixel = inputPixels[g+y];
                
                //loads colours into colour arrays
                alpha[i] = (float)((pixel & 0xff000000) >> 24);
                red[i] = (float)((pixel & 0x00ff0000) >> 16);
                green[i] = (float)((pixel & 0x0000ff00) >> 8);
                blue[i] = (float)((pixel & 0x000000ff) >> 0);
                
                    
                u++;
                if (u==w){
                    if(i==box-1){
                        
                        //sorts the arrays to get mid color and wrrites to targetPixel        
                        Arrays.sort(alpha);
                        Arrays.sort(red);
                        Arrays.sort(green);
                        Arrays.sort(blue);
                        
                        targetPixel = (0xff000000) | (((int) alpha[targetColour]) << 24)
                                                   | (((int) red[targetColour]) << 16)
                                                   | (((int) green[targetColour]) << 8)
                                                   | (((int) blue[targetColour]) << 0);
                        
                                         
                        outputPixels[(g+y)-(width*sidePixels)-sidePixels]=targetPixel;
                        break;

                    }
                    g=g+width-w;
                    u=0;
                    
                }    
                g++;
            }     
        }
        
        long end = System.currentTimeMillis();
        System.out.println("The code took "+(end-start)+" milliseconds to execute");
        //writes to buuffered image
        BufferedImage outputImage = new BufferedImage(width,height,BufferedImage.TYPE_INT_ARGB);
        outputImage.setRGB(0,0,width,height,outputPixels,0,width);
        
        return outputImage;
    }
}
