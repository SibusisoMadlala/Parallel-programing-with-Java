/* Assignment1 Mean FIlter serial code
* 3 August 2022
* SIbusiso Madlala
*/

import java.io.File;
import java.io.IOException;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.awt.Graphics;

public class MeanFilterSerial{

    //main method
    public static void main(String[] args){
    
        try{
            
            //writing inputs to files
            File input = new File(args[0]);
            File output = new File(args[1]); 
            int window = Integer.parseInt(args[2]);
            
            if (window%2==0 || window<=3){
                System.out.println("Enter odd number greater than or equal 3");
                System.exit(0);
            }
            
            if (input==null || output==null){
                System.out.println("please enter file paths and window");
                System.exit(0);
            }
            // reading input image and writing to output image 
            BufferedImage inputImage = ImageIO.read(input);
            
            BufferedImage outImage = filter(inputImage, window);
            
            ImageIO.write(outImage, "png" , output);
            
        }
        catch(IOException e){System.out.println(e);}
    }
    
    // this method filters an image with specific window size
    public static BufferedImage filter(BufferedImage image, int w){
        
        long start = System.currentTimeMillis(); //starting calculating time
        
        // this section creates the arrays that will be used to filter
        int width = image.getWidth();
        int height = image.getHeight();
        int[] inputPixels = image.getRGB(0,0,width,height,null,0,width);
        int[] outputPixels = image.getRGB(0,0,width,height,null,0,width);
                
        int box = w*w;
        
        int sidePixels = (w-1)/2; // this represents the border pixels
        
        //this section is used to stop on the border pixels
        int stopWindow = width; 
        int lastWindow = (width)*(height-(w-1))-(w-1);
        
        
        // sliding window technique
        for (int y=0;y<inputPixels.length;y++){
            
            float alpha=0,red=0, green=0, blue=0;
            int g=0;
            int u=0;
            int targetPixel=0;
            int[] pixels = new int[box];
            
            if (y==lastWindow){break;}
            
            if ((stopWindow-y)<w){
                stopWindow+=width;
                y+=(w-1);
            }
            
            
            for (int i =0 ; i<box;i++){
                
                alpha+=(float)((inputPixels[g+y] & 0xff000000) >> 24);
                red+=(float)((inputPixels[g+y] & 0x00ff0000) >> 16);
                green+=(float)((inputPixels[g+y] & 0x0000ff00) >> 8);
                blue+=(float)((inputPixels[g+y] & 0x000000ff) >> 0);
                
                u++;
                if (u==w){
                    if(i==box-1){
                        alpha=alpha/box;
                        red=red/box;
                        green=green/box;
                        blue=blue/box;
                        
                        targetPixel = (0xff000000) | (((int) alpha) << 24)
                                                   | (((int) red) << 16)
                                                   | (((int) green) << 8)
                                                   | (((int) blue) << 0);
                        
                                         
                        outputPixels[(g+y)-(width*sidePixels)-sidePixels]=targetPixel;
                        break;
                    }
                    g=g+width-w;
                    u=0;
                    
                }    
                g++;
            }     
        }
        long end = System.currentTimeMillis(); // ends calculating time
        
        System.out.println("The code took "+(end-start)+" milliseconds");
        
        //writes to output image
        BufferedImage outputImage = new BufferedImage(width,height,BufferedImage.TYPE_INT_ARGB);
        outputImage.setRGB(0,0,width,height,outputPixels,0,width);
        
        return outputImage;
    }
}
